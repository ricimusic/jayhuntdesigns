$(document).ready (function(){

    $(".burger-nav").on("click", function(){

    	$("ul").toggleClass("open");

    });

});